
//*********************************************************************
// Ð¡ÑÐ°Ð²Ð½Ð¸Ð²Ð°ÐµÐ¼ ÑÑÐ¾Ñ Ð²Ð½ÑÑÑÐµÐ½Ð½Ð¸Ð¹ main.js  ÑÐ°Ð¹Ð» Ñ Ð½Ð°ÑÐ¸Ð¼ ÑÐ¾Ð±Ð±ÑÐ²ÐµÐ½Ð½ÑÐ¼ jQueyr "ourjQuery.js"
//********************************************************************

window.onload = function(Ðµ) {
    var inputs = document.querySelectorAll('.check');

    document.querySelector('form').onsubmit = function(e) {
    	var error = false;

    	for(var i = 0; i < inputs.length; i++){
    		if(inputs[i].value === ''){
    			inputs[i].classList.add('err');
    			error = true;
    		}
    	}
    	if(error) {
    		e.preventDefault();
    	}
    }



   /* for(var i = 0; i < inputs.length; i++){
    	inputs[i].oninput = function(){
    		this.classList.remove('err');
    	}
    }

    for(var i = 0; i < inputs.length; i++){
    	inputs[i].onfocus = function(){
    		this.classList.add('focus');
    	}
    }

    for(var i = 0; i < inputs.length; i++){
    	inputs[i].onblur = function(){
    		this.classList.remove('focus');
    	}
    }*/

   


 
                          /////////////////////
                           /////////////////
                             /////////////
                               /////////
                                 /////
                                  //
   // ÐÑÐ¸Ð¼ÐµÑ ÐºÐ¾Ð³Ð´Ð° , ÐºÐ¾Ð³Ð´Ð° Ð¿Ð¾Ð´ÑÑÐ°Ð²Ð¸Ð»Ð¸ ÑÐ¾ ÑÑÐ¾ Ð¸Ð·  ourjQuery.js  Ð² ÑÐ°Ð¹Ð» main.js Ð¸ ÑÑÐ¾ Ð¸Ð· ÑÑÐ¾Ð³Ð¾ Ð¿Ð¾Ð»ÑÑÐ¸Ð»Ð¾ÑÑ 
   // ÐÐ°Ð¿ÑÐ¸Ð¼ÐµÑ Ð½ÑÐ¶Ð½Ð¾ Ð¿Ð¾Ð»ÑÑÐ¸ÑÑ Ð½Ð°Ð±Ð¾Ñ Ð¸Ð½Ð¿ÑÑÐ¾Ð² 
    var jqInputs = $('.check');   // Ð¢ÑÑ Ñ Ð½Ð°Ñ Ð¾ÐºÐ°Ð·Ð°Ð»Ð°ÑÑ Ð¿ÐµÑÐµÐ¼ÐµÐ½Ð½Ð°Ñ ÑÑÐ¾Ð³Ð¾ ÐºÐ»Ð°ÑÑÐ° ( Ð¸Ð· ÑÐ°Ð¹Ð»Ð° ourjQuery.js ) ÑÑÐ¾ Ð¿Ð¾Ð»ÑÑÐ¸Ð»Ð¾ÑÑ Ð² return new OurJquery(elements);  , ÐºÐ¾ÑÐ¾ÑÐ¾Ðµ Ð²ÐµÑÐ½ÑÐ»Ð¸ Ð² function $(selector){......}

  jqInputs.on('click', function(){ 
                                   
                                 
   this.classList.remove('err');
 });

jqInputs.on('focus', function(){     
 this.classList.add('focus');
});
 

jqInputs.on('blur', function(){     
  this.classList.remove('focus');
  });

console.log(jqInputs); // Ð²ÑÐ²Ð¾Ð´Ð¸Ñ Object { elements: NodeList(3), on: on(eventname, f) } , ÑÑÐ¾ Ð±ÑÐ»Ð¾ Ð²Ð»Ð¾Ð¶ÐµÐ½Ð¾ Ð² function $(selector) Ð° Ð¾ÑÐ¿ÑÐ°Ð²Ð»ÐµÐ½Ð¾ ÑÑÐ´Ð° Ð¾Ñ return new OurJquery(elements);


 //*********************************************************************
// ÐÐ¾ÑÑÐ½ÐµÐ½Ð¸Ðµ ÐºÐ°Ðº ÑÐ°Ð±Ð¾ÑÐ°ÐµÑ jQuery. ÐÑÐ¸Ð¼ÐµÑâ 1 
//********************************************************************* 
 
 jqInputs.addClass('some'); // ÐÐ· ÑÐ°Ð¹Ð»Ð° ourjQuery.js Ð¸ÑÐ¿Ð¾Ð»ÑÐ·ÑÐµÐ¼ Ð¼ÐµÑÐ¾Ð´ .addClass, ÐºÐ¾ÑÐ¾ÑÑÐ¹ Ð¿ÑÐ¾Ð¿Ð¸ÑÐ°Ð»Ð¸ , Ð¸ Ð¿Ð¾Ð´ÑÑÐ°Ð²Ð»ÑÐµÐ¼ Ð²Ð¼ÐµÑÑÐ¾ name , Ð¿Ð¾Ð´ÑÑÐ°Ð²Ð»ÑÐµÐ¼ 'some' ;
                            // ÐÐ¾ Ð²ÑÐµÐ¼ Ð³ÑÑÐ¿Ð¿Ð°Ð¼ ÑÐ»ÐµÐ¼ÐµÐ½ÑÐ¾Ð² Ð±ÑÐ´ÐµÑ Ð´Ð¾Ð±Ð°Ð²Ð»ÐµÐ½ ÐºÐ»Ð°ÑÑ 'some'

$('.items .item').html('1');

}