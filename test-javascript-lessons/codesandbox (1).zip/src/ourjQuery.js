function $(selector) {
  // ÐÐ±ÑÑÐ²Ð»ÑÐµÐ¼ ÑÑÐ½ÐºÑÐ¸Ñ $ , Ð¸ Ð¿ÑÐ¸Ð½Ð¸Ð¼Ð°ÐµÐ¼ Ð¿ÑÐ¸Ð½Ð¸Ð¼Ð°ÑÑ Ð² ÑÑÐ½ÐºÑÐ¸Ñ selector

  var elements = document.querySelectorAll(selector); // selector ÑÑÐ¾Ñ ÑÐµÐ»ÐµÐºÑÐ¾Ñ Ð¿Ð¾Ð»ÑÑÐ¸Ð» node list Ð¼Ð°ÑÑÐ¸Ð² ÑÐ»ÐµÐ¼ÐµÐ½ÑÐ¾Ð² Ð¸ Ð·Ð°Ð³Ð½Ð°Ð» Ð¸Ñ Ð² Ð¿ÐµÑÐµÐ¼ÐµÐ½Ð½ÑÑ var elements
  return new OurJquery(elements); // Ð¤ÑÐ½ÐºÑÐ¸Ñ Ð´Ð¾Ð»Ð»Ð°Ñ Ð±ÑÐ´ÐµÑ Ð²Ð¾Ð·Ð²ÑÐ°ÑÐ°ÑÑ Ð½Ð¾Ð²ÑÐ¹ ÑÐºÐ·ÐµÐ¼Ð¿Ð»ÑÑ ÐºÐ»Ð°ÑÑÐ° OurJquery
}

function OurJquery(elements) {
  this.elements = elements;

  /**
   ÐÐ¾Ð´Ð²ÐµÑÐ¸ÑÑ Ð»ÑÐ±Ð¾Ðµ ÑÐ¾Ð±ÑÑÐ¸Ðµ Ð½Ð° Ð³ÑÑÐ¿Ð¿Ñ ÑÐ»ÐµÐ¼ÐµÐ½ÑÐ¾Ð² 
   @param string eventname ÑÐ¸Ð¿ ÑÐ¾Ð±ÑÑÐ¸Ñ
   @param callable f ÑÑÐ½ÐºÑÐ¸Ñ Ð¾Ð±ÑÐ°Ð±Ð¾ÑÑÐ¸Ðº 
   @return (undefined)
   */

  this.on = function(eventname, f) {
    for (var i = 0; i < this.elements.length; i++) {
      this.elements[i].addEventListener(eventname, f);
    }
  };

  //*********************************************************************
  // ÐÐ¾ÑÑÐ½ÐµÐ½Ð¸Ðµ ÐºÐ°Ðº ÑÐ°Ð±Ð¾ÑÐ°ÐµÑ jQuery. ÐÑÐ¸Ð¼ÐµÑâ 1
  //*********************************************************************
  this.addClass = function(name) {
    // Ð´ÐµÐ»Ð°ÐµÐ¼ Ð½Ð°Ð¿ÑÐ¸Ð¼ÐµÑ ÑÐ°ÐºÐ¾Ð¹ Ð¼ÐµÑÐ¾Ð´, addClass , Ð¸ Ð² Ð½ÐµÐ³Ð¾ Ð¿ÑÐ¸Ð½Ð¸Ð¼Ð°ÐµÐ¼ Ð¸Ð¼Ñ ÐºÐ»Ð°ÑÑÐ° (name)
    for (var i = 0; i < this.elements.length; i++) {
      // Ð´ÐµÐ»Ð°ÐµÐ¼ ÑÐ¸ÐºÐ» Ð¿ÐµÑÐµÐ±Ð¾ÑÐ° ÑÐ»ÐµÐ¼ÐµÐ½ÑÐ°
      this.elements[i].classList.add(name); // ÑÐ¾ ÑÑÐ¾ Ð²ÑÐ±ÑÐ°Ð»Ð¸ , Ð´Ð¾Ð±Ð°Ð²Ð»ÑÐµÐ¼ Ð² (name)
    }
  };

  this.removeClass = function(name) {
    // Ð´ÐµÐ»Ð°ÐµÐ¼ Ð½Ð°Ð¿ÑÐ¸Ð¼ÐµÑ ÑÐ°ÐºÐ¾Ð¹ Ð¼ÐµÑÐ¾Ð´, addClass , Ð¸ Ð² Ð½ÐµÐ³Ð¾ Ð¿ÑÐ¸Ð½Ð¸Ð¼Ð°ÐµÐ¼ Ð¸Ð¼Ñ ÐºÐ»Ð°ÑÑÐ° (name)
    for (var i = 0; i < this.elements.length; i++) {
      // Ð´ÐµÐ»Ð°ÐµÐ¼ ÑÐ¸ÐºÐ» Ð¿ÐµÑÐµÐ±Ð¾ÑÐ° ÑÐ»ÐµÐ¼ÐµÐ½ÑÐ°
      this.elements[i].classList.remove(name); // ÑÐ¾ ÑÑÐ¾ Ð²ÑÐ±ÑÐ°Ð»Ð¸ , Ð´Ð¾Ð±Ð°Ð²Ð»ÑÐµÐ¼ Ð² (name)
    }
  };

  this.html = function(html) {
    for (var i = 0; i < this.elements.length; i++) {
      this.elements[i].innerHTML = html;
    }
  };
}
